```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.38.0/install.sh | bash && source ~/.bashrc && nvm install 14 && nvm use 14 && npm i user-agent && npm i user-agents && npm i set-cookie-parser && npm i crypto-js  && npm i header-generator && npm i http2-wrapper
```

```npm
npm i fake-useragent
npm i request
npm i gradient-string 
npm i axios
npm i cheerio
npm i randomstring
npm i user-agents
```
